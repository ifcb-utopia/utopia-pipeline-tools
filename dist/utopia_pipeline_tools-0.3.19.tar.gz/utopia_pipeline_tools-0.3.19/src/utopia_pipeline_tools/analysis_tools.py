""" Analysis Tools Module

Contains functions to analyze data post-CNN-classification and validation.
"""

# some functions might be nice :)